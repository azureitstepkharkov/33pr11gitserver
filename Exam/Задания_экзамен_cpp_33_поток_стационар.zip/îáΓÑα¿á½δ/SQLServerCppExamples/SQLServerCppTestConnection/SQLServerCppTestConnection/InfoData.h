#pragma once
#include <string>
using namespace std;
struct InfoData
{
	int id;
	string name;
};


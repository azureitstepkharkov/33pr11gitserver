#pragma once
int fnMySum(int a, int b);
